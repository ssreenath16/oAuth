package com.eureka.common.security;

public enum UserRole {
	USER, ADMIN;
}
